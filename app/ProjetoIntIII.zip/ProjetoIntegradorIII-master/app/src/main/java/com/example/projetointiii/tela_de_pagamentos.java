package com.example.projetointiii;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class tela_de_pagamentos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela_de_pagamentos);
    }
}